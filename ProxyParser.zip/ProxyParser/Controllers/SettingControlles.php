<?php namespace ProxyManager\Controllers;

use ProxyManager\ProxyManager;
use ProxyManager\ProxyController;
use ProxyManager\Controllers\ListFileControllers;
use ProxyManager\Controllers\InputCheckControllers;
use ProxyManager\Controllers\CheckerControllers;
use ProxyManager\Controllers\MetothodSearchControllers;
use ProxyManager\Controllers\SearchParametrs\ApiParametrs;
use ProxyManager\Controllers\SearchParametrs\ParserParametrs;


class SettingControlles
{

	public static $MetothodSearch;
	public static $FileNameSearchers;
	public static $FileNameValid;
	public static $DIRHoumeLogData;
	public static $DIRHoumeValid;
	public static $CountInputProxyerArr;
	public static $CountForCicly;	
	public static $ChekersConfig;
	
	
	/**                                                       
     * @param Client 
	 * $Proxy
     */
    public static function initMethod($MetothodSearch){
		self::$MetothodSearch = $MetothodSearch;
	}
	
	/**                                                       
	* @param Client 
	* $Proxy
	*/
    public static function initFileName($FileNameSearchers, $FileNameValid){
		self::$FileNameSearchers = $FileNameSearchers;
		self::$FileNameValid = $FileNameValid;
	
	}
	
	
	/**                                                       
     * @param Client 
	 * $Proxy
     */
    public static function initDIRHoume($DIRHoume){
		self::$DIRHoumeLogData = $DIRHoume."/LogData";
		self::$DIRHoumeValid = $DIRHoume."/LogData/Valid";
	}	
	
	
	/**
	* @return string
	*/
    public static function getMetothodSearch(){
        return self::$MetothodSearch;
    }
	
	/**
	* @return string
	*/
    public static function getFileNameSearchers(){
        return self::$FileNameSearchers;
    }
	
		
	/**
	* @return string
	*/
    public static function getFileNameValid(){
        return self::$FileNameValid;
    }
	
	
	/**
	* @return string
	*/
    public static function getDIRHoumeLogData(){
        return self::$DIRHoumeLogData;
	}
	
	/**
	* @return string
	*/
    public static function getDIRHoumeValid(){
        return self::$DIRHoumeValid;
	}
	
	/**                                                       
     * @param Client 
	 * $Proxy
     */
    public static function initCountInputProxyerArr($CountInputProxyerArr){
		self::$CountInputProxyerArr = $CountInputProxyerArr;	
	}
	
	/**
	* @return string
	*/
    public static function getCountInputProxyerArr(){
        return self::$CountInputProxyerArr;
	}
	
	/**                                                       
     * @param Client 
	 * $Proxy
     */
    public static function initCountForCicly($CountForCicly){
		self::$CountForCicly = $CountForCicly;	
	}	

	/**
	* @return string
	*/
    public static function getCountForCicly(){
        return self::$CountForCicly;
	}
	
	/**                                                       
	* @param Client 
	* $Proxy
	*/
    public static function initChekersConfig($ChekersConfig){
		self::$ChekersConfig = $ChekersConfig;
	}
	
	/**
	* @return string
	*/
    public static function getChekersConfig(){
        return self::$ChekersConfig;
	}
	
	public function __construct(){
    }
}
?>