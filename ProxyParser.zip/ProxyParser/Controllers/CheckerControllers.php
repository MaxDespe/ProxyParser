<?php namespace ProxyManager\Controllers;

use ProxyManager\Controllers\InputCheckControllers;
use ProxyManager\Checker\ProxyCheckerCore;
use ProxyManager\Controllers\ListFileControllers;
use ProxyManager\Controllers\SettingControlles;


/**
* @return string
*/
class CheckerControllers
{
	
	/**
	* @return string
	*/
	public $FileNameValidtxt;
	public $FileNameValid;
	public $FileNameSearcherstxt;
	public $OutProxyArr;
	public $CountInputProxyerArr;
	public $CountForCicly;
	public $CountCiclyFive;
	public $CheckResponses = array();
	
	

	/**
	* @return string
	*/
	public function __construct(){	

		$this->getIncludeFileNameValid();
		$this->getIncludeArrayProxye();
	} 

	/**
	* @return string
	*/
    public function getIncludeFileNameValid(){
		$InFile =  new InputCheckControllers();
		$this->FileNameValidtxt = $InFile->FileNameValid;
		$this->FileNameValid = $InFile->setChecValidFiles();
    }
	
	/**
	* @return string
	*/
    public function getIncludeArrayProxye(){
		$InFile =  new InputCheckControllers();
		$this->FileNameSearcherstxt = $InFile->FileNameSearchers;
		$this->OutProxyArr = $InFile->getFileOutProxyArr(SettingControlles::getDIRHoumeLogData(), $this->FileNameSearcherstxt);
		
		SettingControlles::initCountInputProxyerArr($InFile->getProxyCountArr($this->OutProxyArr));	
		SettingControlles::initCountForCicly(intval($InFile->getProxyCountArr($this->OutProxyArr)/5));	
		$this->CountInputProxyerArr = SettingControlles::getCountInputProxyerArr();
		$this->CountForCicly = SettingControlles::getCountForCicly();
	
    }
	
	
	
	/**
	* @return string
	*/
    public function getChckArr($ChekersConfig){

		$Url = "https://bot.shopvw.pw/ping.php";
		$this->proxyChecker = new ProxyCheckerCore($Url,  $ChekersConfig);
		$InFile =  new InputCheckControllers();
		$ProxyArr = $this->OutProxyArr;
	
		$OutProxyArr = array_diff($ProxyArr, array_diff_assoc($ProxyArr, array_unique($ProxyArr)));
		
		if(SettingControlles::getCountInputProxyerArr() > 100){
			$OutProxyArr = array_splice($this->OutProxyArr, -100);
		}
		$JobsArray = array_diff($OutProxyArr, array(''));
		$ToFaile = new ListFileControllers(SettingControlles::getDIRHoumeLogData());
		$ToFaile->setNameFile($this->FileNameSearcherstxt);
		$editarray = $ToFaile->getFileArray();
		$ArrayParseds = array_diff ($editarray, $JobsArray);
		$ToFaile->setSearcherListToFile($ArrayParseds);
		//  массив состоящий из 20 массивов по 5 прокси 
		$ArrProxyesByCiclyFive = $InFile->getCutCycleArrToProxy($JobsArray);
		$this->CountCiclyFive = $InFile->getProxyCountArr($ArrProxyesByCiclyFive);
		
		$y = 5;
		for($x=0; $x < $y;)
		{
			//set_time_limit(360);
			foreach($ArrProxyesByCiclyFive as $value)
			{
				$proxiesarr  = $value[$x];
				$CheckProxiesParse = $this->getCheckProxiesParse($value)[$x];
				echo  "<br>"; 
			}
			if($x==5) continue;
			sleep(8);
			$x++;
		} 
		//$proxies = $InFile->getOneArr($ArrProxyesByCiclyFive);
	}
	
	/**
	* @return string
	*/
    public function getCheckProxiesParse($Data){
		$Responses = $this->proxyChecker->checkProxies($Data);
		$this->CheckResponses =  $Responses;		
		foreach($this->CheckResponses as $keys=>$values){
			foreach($values as $key=>$val){
				if($key == 'allowed'){
					$input = $keys;
					$ToFaile = new ListFileControllers(SettingControlles::getDIRHoumeValid());
					$ToFaile->setFwriteValidProxy($input);
				}			
			}
		} 
		//return $this->CheckResponses =  $Responses;
    }
	
	
	/**
	* @return string
	*/
    public function getOneArrayProxyToParse() 
    {
		return $this->OneArrayProxyToParse;
    }
}



/* Результат
Разрешено / Недопустимое
Массив разрешил / запретил операции прокси (get, post, referer, cookie, user_agent), например:

'allowed' => array (
    0 => 'get',
    1 => 'post',
    2 => 'referer',
    3 => 'user_agent'
)

'disallowed' => array (
    0 => 'cookie'
)
Уровень прокси
elite - соединение выглядит как обычный клиент, 
анонимный - ни один ip не переадресован, но целевой сайт все еще может сказать, что он прокси- 
прозрачен - ip переадресован, и целевой сайт сможет сказать, что это прокси 

'proxy_level' => 'elite',
Другая информация
Другая информация прокси-сервера - время, http-код, количество перенаправлений, скорость и т. Д .:

'info' => array (
  'content_type' => 'text/html',
  'http_code' => 200,
  'header_size' => 237,
  'request_size' => 351,
  'ssl_verify_result' => 0,
  'redirect_count' => 0,
  'total_time' => 1.212548,
  'connect_time' => 0.058647,
  'size_upload' => 143,
  'size_download' => 485,
  'speed_download' => 399,
  'speed_upload' => 117,
  'download_content_length' => 485,
  'upload_content_length' => 143,
  'starttransfer_time' => 1.059746,
  'redirect_time' => 0,
  'certinfo' => array (),
),


 */
 ?>