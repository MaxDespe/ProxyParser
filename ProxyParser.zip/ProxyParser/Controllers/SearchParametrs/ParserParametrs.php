<?php namespace ProxyManager\Controllers\SearchParametrs;

class ParserParametrs
{
	public function __construct(){
		$this->getDefaultParametrs();
	}
	
	public function getDefaultParametrs(){
		$this->sitesSet = array_shift($this->getSitesSet());
		
	}
	
	public function getSitesSet(){
		$Value = array('Soks4Proxy', 'UsProxyOrg', 'ProxyListeDe', 'SslProxiesOrg', 'FreeProxyListNet');
		return list($sitesSet[0], $sitesSet[1], $sitesSet[2], $sitesSet[3], $sitesSet[4]) = $Value;
	}
	
}
?>