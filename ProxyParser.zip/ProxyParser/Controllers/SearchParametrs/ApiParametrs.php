<?php namespace ProxyManager\Controllers\SearchParametrs;

class ApiParametrs
{
	/**
	* @return array
	*/
	public function __construct(){
		$this->ApiRouteUrl = $this->setRouteUrl();
		$this->getDefaultParametrs();
	}
	
	/**
	* @return array
	*/
	public function getDefaultParametrs(){
		$this->type = array_shift($this->settType());
		$this->anon = array_shift($this->setAnon());
		$this->country = $this->getRandomEl($this->setCountry());
	}
	
	/**
	* @return array
	*/
	public function setFullListParametrs(){
		$this->type = $this->settType();
		$this->anon = $this->setAnon();
		$this->country = $this->setCountry();
		return $this;
	}
	
	/**
	* @return array
	*/
	public function getRandomEl($array){
		return $array[mt_rand(0, count($array)-1)];
	}
	/**
	* @return array
	*/
	public function getArrayKeys(){
		$this->type = array_shift($this->settType());
		$this->anon = array_shift($this->setAnon());
		$this->country = array_shift($this->setCountry());
	}
	
	/**
	* @return array
	*/
	public function settType(){
		$Value = array('https', 'http', 'socks4', 'socks5');
		return list($type[0], $type[1], $type[2], $type[3]) = $Value;
	}
	
	/**
	* @return array
	*/	
	public function setAnon(){
		$Value  = array('elite', 'anonymous', 'transparent');
		return list($anon[0], $anon[1], $anon[2]) = $Value;
	}
	
	/**
	* @return array
	*/	
	public function setCountry(){
		$Value = array('DE', 'AT', 'NO', 'GB', 'BR');
		return list($country [0], $country [1], $country [2], $country [3], $country[4]) = $Value;
	}
	
	/**
	* @return array
	*/	
	public function setRouteUrl(){
		return "https://www.proxy-list.download/api/v1/get";
	}
}
?>