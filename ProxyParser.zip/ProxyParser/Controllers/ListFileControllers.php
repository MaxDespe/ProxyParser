<?php namespace ProxyManager\Controllers;

use ProxyManager\ProxySearcher\ProxySearcher;
use ProxyManager\ProxySearcher\SearcherList;
use ProxyManager\Controllers\SettingControlles;


class ListFileControllers
{
	
	public $myFile;
	protected $logdirname;
	
	
	/**
	* @return array
	*/
    public function __construct($dir)
	{
		return $this->logdirname = $dir;
	}
	
	/**
	* Задаем имя файлу
	* @return array
	*/
	public function setNameFile($FileName){
		$logdir = $this->logdirname;
		
		if(!file_exists($logdir)){
			if(!mkdir($logdir, 0777, true)){
				die("Не удалось создать каталог $logdir");
			}
		}
		
		$myFile =  $logdir."/$FileName";
		$this->myFile = $myFile;
		return $this;
	}
	
	/**
	*  Проверяем наличие файла
	* @return array
	*/
	public function setFileExists(){
		if(file_exists($this->myFile)){
			return true;	
		
		}else return false;
	}

	/**
	* @return array
	*/
	public function setFwriteValidProxy($data)
	{
		$FileName = SettingControlles::getFileNameValid();
		$this->setNameFile($FileName); 
		
			$fh = fopen($this->myFile, 'a+');
		
			if((is_array($data)) || (is_object($data)))
			{
				foreach($data as $key=>$value)
				{
					$record = fwrite($fh, $value .",\n");
				}			
			}else{
				$record = fwrite($fh, $data);
			}
			
			if ($record)echo 'Данные в файл успешно занесены. <br />';
			else echo 'Ошибка при записи в файл. <br />';
			fclose($fh);
		
	}
	
	
	/**
	* @return array
	*/
	public function setSearcherListToFile($data){
		
		$FileName = SettingControlles::getFileNameSearchers();
		$this->setNameFile($FileName); 
			$fh = fopen($this->myFile, 'a+');
		
			if((is_array($data)) || (is_object($data))){
				foreach($data as $key=>$value){
					$record = fwrite($fh, $value.",\n");
				}			
			}else{
				$record = fwrite($fh, $data ." \n");
			}
			
			if ($record)echo 'Данные в файл успешно занесены. <br />';
			else echo 'Ошибка при записи в файл. <br />';
			fclose($fh);
		
	}
	
	/**
	*	Возвращает время последнего изменения указанного файла. 
	*	Изменяется при создании, изменении файла. или FALSE 
	*	Эта функция проверяет наличие изменений в Inode файла, и обычных изменений. 
	*	Изменения Inode - это изменение разрешений, владельца, группы и других метаданных.
	* 
	*	@return array
	*/
	public function setTimeEditFile(){
		return filectime($this->myFile);
	}
	
	/**
	*	Возвращает время последнего изменения контента файла. Изменяется при изменении контента файла.
	* 
	*	@return array
	*/
	public function setTimeContentFile(){
		return filemtime($this->myFile);
	}
	
	/**
	*	Возвращает размер файла	* 
	*	@return array
	*/
	public function getSizeFile(){
		return filesize($this->myFile);
	}
	
	public function getReadFile(){
		return readfile ($this->myFile);
	}
	/**
	*	Считываем файл целиком в массив
	* 	@return array
	*/
	public function getFileArray(){
		return file($this->myFile, FILE_SKIP_EMPTY_LINES); // Считывание файла в массив $file_array
	}

	/**
	* @return array
	*/
	public function getFileArrayString(){
		$lines = file($this->myFile);
		// Осуществим проход массива и выведем содержимое в виде HTML-кода вместе с номерами строк.
		foreach ($lines as $line_num => $line){
			echo "Строка #<b>{$line_num}</b> : " . htmlspecialchars($line) . "<br />\n";
		}
	}
	
	/** Удаляем файл
	* @return array
	*/
	public function setDeleteMyfile(){
		return unlink($this->myFile);	
	}
	
	/**
	*	Очищает кеш состояния файлов
	*	 @return array
	*/
	public function setDeleteCash(){
		return clearstatcache();	
	}
}

?>