<?php namespace ProxyManager\Controllers;

use ProxyManager\Controllers\ListFileControllers;
use ProxyManager\Controllers\SettingControlles;
use ProxyManager\ProxyManager;
use ProxyManager\ProxyController;


class InputCheckControllers
{
	
	/**
	* @return string
	*/
    public function __construct(){	
		$this->FileNameValid = SettingControlles::getFileNameValid();
		$this->FileNameSearchers = SettingControlles::getFileNameSearchers();
		// $setChecValidFiles = $this->setChecValidFiles(); 
		// return $this->FileOutProxyArr =  $this->getFileOutProxyArr();
	}
	
	/**
	* @return string
	*/
    public function setChecValidFiles(){
		//$this->FileNameValid = SettingControlles::getFileNameValid();
		if(! ProxyController::setLoadFileName(SettingControlles::getDIRHoumeValid(), $this->FileNameValid)){		
			echo "Файл пуст/удален. Совершаем новый поиск <br />";
			return $this->StatusFileNameValid = 'false';
		}
		
		elseif(ProxyController::setEditFileTime(SettingControlles::getDIRHoumeValid(), $this->FileNameValid)){
			echo "Время с момента парсинга прокси привышает 1 час <br />";
			return $this->StatusFileNameValid = 'false';
		}
		else{
			echo "Файл еще имеет данные <br />";
			return $this->StatusFileNameValid = 'true';
		}
	}
	
	/**
	* @return array
	*/
    public function getFileOutProxyArr($dirname, $FileName){
		//$this->FileNameSearchers = SettingControlles::getFileNameSearchers();
		$ToFaile = new ListFileControllers($dirname);
		$ToFaile->setNameFile($FileName);
		return $ToFaile->getFileArray(); 
	}	

	
	
	/**
	* @return array
	*/
	public function getProxyCountArr($ArrayProxyes){
		return count($ArrayProxyes);
	}
	
	/**
	* @return array
	*/
    public function getCutCycleArrToProxy($ArrayProxyes){
		return array_chunk($ArrayProxyes, 5, true);
	}
	
	/**
	* @return array
	*/
    public function getOneCycleArrSetKey($InputArrayProxyes){
		
		foreach($InputArrayProxyes as $key => $value){
			return $value;
		}
    }
	
	/**
	* @return array
	*/
    public function getOneArr($InputArrayProxyes){
		foreach($this->getOneCycleArrSetKey(array_diff($InputArrayProxyes, array(''))) as $key => $value){
			$proxies = $value;
		}
		return ($proxies);
    }
	
}
?>
