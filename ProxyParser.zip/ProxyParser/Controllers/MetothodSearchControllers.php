<?php namespace ProxyManager\Controllers;


use ProxyManager\Controllers\SearchParametrs\ApiParametrs;
use ProxyManager\Controllers\SearchParametrs\ParserParametrs;


class MetothodSearchControllers
{

	public $MetothodSearchConfig = array(
	   'MetothodSearch' => array('APISearcher', 'ParserSearcher')
	);

	public function __construct($MetothodSearchConfig){
		$this->setMetothodSearchConfig($MetothodSearchConfig);
		$this->setParametrs();
	}
	
	
	public function setMetothodSearchConfig($MetothodSearchConfig){
        $this->MetothodSearchConfig = array_merge($this->MetothodSearchConfig, $MetothodSearchConfig);
    }

	public function setParametrs(){
		
		if(in_array('APISearcher', $this->MetothodSearchConfig['MetothodSearch'])){
		return array_push($this->MetothodSearchConfig, ['ApiParametrs' => new ApiParametrs()]);
        }	
		if(in_array('ParserSearcher', $this->MetothodSearchConfig['MetothodSearch'])){
			return array_push($this->MetothodSearchConfig, ['ParserSearcher' => new ParserParametrs()]);
		}
	}
	
	public function getApiParametrs(){
		return $this->ApiParametrs;
	}
	
	public function getParserParametrs(){
		return $this->ParserParametrs;
	}
	
	/**
	*
    */
	public function InputMetothodSearchForms() 
	{
		?>
		<form role="form" name="MetothodSearch" method="POST" action=" "> 
		<div class="form"><label for="MetothodSearch">Выбрать поиска</label>
		<select name="SelectionOperation" size="1">
		<?php
			$Operations = $this->MetothodSearchConfig['MetothodSearch'];
			foreach ($Operations as $value) 
			{ 
				?><option value="<?=$value?>"><?=$value?></option><?php
			}
			?>
		</select></div>
		<input type="submit" name="MetothodSearch" value="Отправить"></div>
		</div>
		</form>
		<?php
	}
	
}

?>