<?php namespace ProxyManager\Controllers;


use ProxyManager\Controllers\ListFileControllers;
use ProxyManager\Controllers\MetothodSearchControllers;
use ProxyManager\ProxySearcher\ApiProxySeacher;
use ProxyManager\ProxySearcher\ProxySearcher;
use ProxyManager\Controllers\SettingControlles;

class SearcherControllers
{


	public $MetothodSearch;
	public $ParametrsSearch;
	
	
	/**
	* @return string
	*/
    public function __construct(array $MetothodSearchConfig = array()) 
    {
		$this->setMetothodSearch($MetothodSearchConfig);
		//$this->setFileName();
	}
	
	/**
	* @return array
	*/
    public function setMetothodSearch(array $MetothodSearchConfig)
    {
		$MetothodSearch = new MetothodSearchControllers($MetothodSearchConfig);
		foreach($MetothodSearch as $Val){
			$arraypshift = $this->array_pshift($Val);
			SettingControlles::initMethod($this->array_pshift($arraypshift));
			$this->MetothodSearch = SettingControlles::getMetothodSearch();
			foreach($Val as $key => $arr){
				$this->ParametrsSearch = $this->array_pshift($arr);
			}	
        }
		$this->setFileName();
		return $this;
    }
	
	
	/**
	* @return array
	*/
	public function array_pshift($array)
	{ 
		$keys = array_keys($array); 
		$key = array_shift($keys); 
		$element = $array[$key]; 
		unset($array[$key]); 
		return $element; 
	} 
	
	
	
	/**
	* @return array
	*/
	public function getList()
	{ 
		if($this->MetothodSearch == 'ParserSearcher')
		{
			$ProxyData = $this->ParametrsSearch->sitesSet;
			$SearcherList = $this->setParserSearcherList();
		}
		if($this->MetothodSearch == 'APISearcher')
		{
			$SearcherList = $this->setAPISearcherList();
		}
		$CountProxyArr = $this->getProxyCountArr($SearcherList);	
		$this->CountProxyArr = $CountProxyArr;
		$this->ChekerCikls = intval($CountProxyArr/5);
	} 
	
	/**
	* @return string
	*/
    public function setAPISearcherList()
	{
		$ApiRouteUrl = $this->ParametrsSearch->ApiRouteUrl;
		$type = $this->ParametrsSearch->type;
		$anon = $this->ParametrsSearch->anon;
		$country = $this->ParametrsSearch->country;
	
		$URL = "https://www.proxy-list.download/api/v1/get?type=".$type."&anon=".$anon."&country=".$country;
		$ApiProxyList = new ApiProxySeacher($URL);
		$result[] = array_unique($ApiProxyList->getApiSearchers());
	
		$ToFaile = new ListFileControllers(SettingControlles::getDIRHoumeLogData());
		
		$ToFaile->setSearcherListToFile($result);
		$responses = $ToFaile->getFileArray();
		return $this->ApiProxyList = $responses;
		
	}	
	
	
	
	/**
	* @return string
	*/
    public function setParserSearcherList($ProxyData){
		
		$ProxyList = $this->getProxySearcher();
		$ToFaile = new ListFileControllers(SettingControlles::getDIRHoumeLogData());
	
	if($ProxyData == 'Soks4Proxy'){
			$result 	= $ProxyList['Soks4Proxy'];
			$ToFaile->setSearcherListToFile(array_unique($result));
			return $this->Soks4Proxy = array_unique($result);
		}
		if($ProxyData == 'FreeProxyListNet'){
			$result 	=  $ProxyList['FreeProxyListNet'];
			$ToFaile->setSearcherListToFile(array_unique($result));
			return $this->FreeProxyListNet = array_unique($result);
		}
		if($ProxyData == 'SslProxiesOrg'){
			$result	=  $ProxyList['SslProxiesOrg'];
			$ToFaile->setSearcherListToFile(array_unique($result));
			return $this->SslProxiesOrg	= array_unique($result); 
		}
		if($ProxyData == 'ProxyListeDe'){
			$result	=  $ProxyList['ProxyListeDe'];
			$ToFaile->setSearcherListToFile(array_unique($result));
			return $this->ProxyListeDe		= array_unique($result); 
		}
		if($ProxyData == 'UsProxyOrg'){
			$result =  $ProxyList['UsProxyOrg'];
			$ToFaile->setSearcherListToFile(array_unique($result));
			return $this->UsProxyOrg 		= array_unique($result); 
		}else{
			return false;
		}
		
	}
	

	/**
	* @return array
	*/
    public function getProxySearcher()
    {
		$Searcher = new ProxySearcher();
		return $Searcher->run();
    }

	/**
	* @return array
	*/
    private function setFileName(){
		if(SettingControlles::getMetothodSearch() == 'ParserSearcher'){
			$FileNameSearchers = $this->ParametrsSearch->sitesSet.'.txt';
			$FileNameValid = "ValidProxyList_".$this->ParametrsSearch->sitesSet.'.txt';
			SettingControlles::initFileName($FileNameSearchers, $FileNameValid); 		
		}
		if(SettingControlles::getMetothodSearch() == 'APISearcher'){
			$FileNameSearchers = $this->MetothodSearch.'To'.$this->ParametrsSearch->type.'countr'.$this->ParametrsSearch->country.'.txt';
			$FileNameValid = "ValidProxyListApi".'_'.$this->ParametrsSearch->country.'_'.$this->ParametrsSearch->type.'.txt';
			SettingControlles::initFileName($FileNameSearchers, $FileNameValid);
		}	
	}
	
	
	/**
	* @return array
	*/
	public function getProxyCountArr($data){
		return count($data);
	}
	
	/**
	* @return array
	*/
    public function get_KeysArr($data){
		return array_flip($data);
	}
	
}
?>	