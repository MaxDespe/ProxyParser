<?php

namespace ProxyManager\ProxySearcher\sites;


use ProxyManager\ProxySearcher\BaseSiteCom;

/**
 * Все прокси выдаются сразу, без пейджинга
 * Затем через js они преобрауются на странице, но в курле имеют отличный от браузерного вид
 * Class UsProxyOrg
 * @package proxier\sites
 */
class Soks4Proxy extends BaseSiteCom
{

    protected $config = array('baseUrl' => 'https://www.socks-proxy.net/');

    public function parse()
    {
        $idTable = "proxylisttable";
        $this->parseTable($idTable);
    }
}