<?php  namespace ProxyManager\ProxySearcher;

class ApiProxySeacher
{
	public function __construct($URL)
    {
		$this->URL = $URL;
	}
	
	public function getApiSearchers()
    {
		if($curl = curl_init())
		{
			curl_setopt($curl, CURLOPT_URL, $this->URL);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER,true);
			$out = curl_exec($curl);
			curl_close($curl);
		}
		return $out;
		
	}
}
?>