<?php namespace ProxyManager\ProxySearcher;

use ProxyManager\ProxySearcher\BaseSiteCom;
use ProxyManager\ProxySearcher\sites\ProxitoryCom;
use ProxyManager\ProxySearcher\sites\UsProxyOrg;
use ProxyManager\ProxySearcher\sites\PublicProxyServersCom;
use ProxyManager\ProxySearcher\sites\ProxyListeDe;
use ProxyManager\ProxySearcher\sites\Soks4Proxy;
use ProxyManager\ProxySearcher\sites\HideMyAssCom;


class ProxySearcher
{
    protected $options = array();
    protected $proxies = array();
    protected $errors = array();

	
	
    public function __construct($options = array())
    {
        $this->options = $options;
    }

	/**
	* @param array $sitesSet
	*	'Soks4Proxy' => true,
    *    'SslProxiesOrg' => true
	*	'UsProxyOrg' => true,
	*	'ProxyListeDe' => true,
	*   'FreeProxyListNet' => true,
	* @return array
	*/
    public function run($sitesSet = array())
    {
        $sites = $sitesSet ? $sitesSet : [

    		'Soks4Proxy' => true,
			'UsProxyOrg' => true,
			'ProxyListeDe' => true,
            'SslProxiesOrg' => true,
			'FreeProxyListNet' => true,
        ];
       
		foreach ($this->options as $key => $optVal)
		{
            if (in_array($key, $sites) && !$optVal)
			{
                $sites[$key] = false;
            }
        }
       
		foreach ($sites as $site => $available)
		{
            if (!$available){
                continue;
            }
            $ns = __NAMESPACE__ . "\\sites\\";
            $siteClass = $ns . $site;
            
			/**
             * @var BaseSiteCom $class
             */
            $class = new $siteClass();
            $class->parse();
		    foreach($class->getErrors() as $err){
                $this->setError($err);
            }
		    $this->proxies[$site] = array_unique($class->getParsedProxies());
        }
        return $this->proxies;
    }
   

    /**
     * @param $error
     * @return $this
     */
    public function setError($error)
    {
        $this->errors[] = $error;
        return $this;
    }

    /**
     * @return array
     */
    public function getErrors()
    {
        return $this->errors;
    }
}